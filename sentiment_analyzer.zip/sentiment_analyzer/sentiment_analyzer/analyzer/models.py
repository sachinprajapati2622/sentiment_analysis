from django.db import models

class SentimentAnalysis(models.Model):
    text = models.TextField()
    sentiment = models.CharField(max_length=20)
    numerical_value = models.FloatField()
    positive_score = models.FloatField(default=0.0)   
    negative_score = models.FloatField(default=0.0)   
    neutral_score = models.FloatField(default=100.0)  
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sentiment} ({self.numerical_value:.2f})"