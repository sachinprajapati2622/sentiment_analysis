from django.shortcuts import render
from .forms import TextAnalysisForm
from .ml_model import analyze_sentiment
import plotly.express as px
from .models import SentimentAnalysis

def analyze_text(request):
    if request.method == 'POST':
        form = TextAnalysisForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['text_input']
            
            # Get all sentiment scores
            results = analyze_sentiment(text)
            
            # Convert to percentages
            pos_percent = results['pos'] * 100
            neg_percent = results['neg'] * 100
            neu_percent = results['neu'] * 100
            
            # Save to database
            analysis = SentimentAnalysis.objects.create(
                text=text,
                sentiment=results['sentiment'],
                numerical_value=results['compound'],
                positive_score=pos_percent,
                negative_score=neg_percent,
                neutral_score=neu_percent
            )

            # Create visualization
            fig = px.bar(
                x=['Positive', 'Negative', 'Neutral', 'Compound'],
                y=[pos_percent, neg_percent, neu_percent, results['compound'] * 100],
                labels={'x': 'Metric', 'y': 'Value (%)'},
                title='Sentiment Analysis Breakdown',
                color=['Positive', 'Negative', 'Neutral', 'Compound'],
                color_discrete_map={
                    'Positive': 'green',
                    'Negative': 'red',
                    'Neutral': 'blue',
                    'Compound': 'purple'
                }
            )
            chart = fig.to_html()
            
            return render(request, 'analyzer/results.html', {
                'text': text,
                'sentiment': results['sentiment'],
                'compound': round(results['compound'], 4),
                'pos': round(pos_percent, 1),
                'neg': round(neg_percent, 1),
                'neu': round(neu_percent, 1),
                'chart': chart
            })
    else:
        form = TextAnalysisForm()
    return render(request, 'analyzer/analyze.html', {'form': form})