from django import forms

class TextAnalysisForm(forms.Form):
    text_input = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'text-input',
            'placeholder': "Share what's in your heart... I'll decode your emotions 💭❤️🤗📊"
        }),
        label=''
    )